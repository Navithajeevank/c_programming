#include<stdio.h>
int main()
{
    int left,right,mid,size=9,key;
    int arr[10]={10,12,15,16,18,20,23,26,28};
    left=0;
    right=size-1;
    printf("enter the element to search:");
    scanf("%d",&key);
    while(left<=right)
    {
        mid=(left+right)/2;
        
        if(arr[mid]==key)
        {
            printf("key found at position %d",mid);
            break;
        }
        else if(arr[mid]>key)
        {
            right=mid-1;
        }
        else
        {
            left=mid+1;
        }
    }
    if(left>right)
    {
        printf("key not found in the list");
    }
    
}