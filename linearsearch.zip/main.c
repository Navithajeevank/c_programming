#include<stdio.h>
int main()
{
    int arr[10]={10,34,55,33,22,12};
    int size=6,key,i;
    printf("enter the element to search:");
    scanf("%d",&key);
    
    
    for(int i=0;i<size;i++)
    {
        if(key==arr[i])
        {
            printf("key is found at %d position",i);
            break;
        }
    }
    if(i==size)
    {
        printf("not found");
    }
    
}