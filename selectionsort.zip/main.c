#include<stdio.h>
int main()
{
    int a[10]={13,2,34,22,12,8};
    int i,j,temp,n=6,min_indx;
    printf("before swapping:");
    for(i=0;i<n;i++)
    {
        printf("%d\t",a[i]);
    }
    for(i=0;i<n;i++)
    {
        min_indx=i;
        for(j=i+1;j<n;j++)
        {
           if(a[j]<a[min_indx])
           {
               min_indx=j;
           }
        }
        
        if(min_indx!=i)
        {
            temp=a[i];
            a[i]=a[min_indx];
            a[min_indx]=temp;
        }
    }
    
    printf("\nafter swaping:");

    for(i=0;i<n;i++)
    {
        printf("%d\t",a[i]);
    }
    
}